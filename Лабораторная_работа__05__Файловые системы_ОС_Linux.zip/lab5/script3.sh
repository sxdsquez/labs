#!/bin/bash

#Разработать и реализовать bash-сценарий, подсчитывающий и перечисляющий все символические ссылки на файл в разных каталогах

#	для примера можете ввести след команды:
#touch original.txt
#ln original.txt hardlink.txt         # жёсткая ссылка
#link original.txt linked.txt	  # жёсткая ссылка
#ln -s original.txt symlink.txt     # символическая
#cp original.txt copy.txt             # копия файла (не ссылка)

# Проверка аргумента
if [ -z "$1" ]; then
  echo "Введите /путь/к/файлу"
  exit 1
fi

# Получаем абсолютный путь к файлу
target_file=$(realpath "$1")

echo "Поиск всех символических ссылок, указывающих на: $target_file"
echo

# Найдём все символические ссылки и сравним с целевым файлом
count=0
while IFS= read -r symlink; do # read читает строку (в данном случае имя символической ссылки) из вывода find
                               # и сохраняет ее в переменную symlink. 
  resolved=$(readlink -f "$symlink" 2>/dev/null)
#readlink -f "$symlink" — эта команда выводит реальный путь, на который ссылается символическая ссылка.
  if [ "$resolved" = "$target_file" ]; then
    echo "Найдена: $symlink"
    ((count++))
  fi
done < <(find / -type l 2>/dev/null) # ищет все символические ссылки (файлы, которые ссылаются на другие
                                     # файлы или каталоги) начиная с корня (/). Эта конструкция позволяет
                                     # передать вывод команды find в цикл while как стандартный ввод.

echo
echo "Всего найдено ссылок: $count"
