#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/wait.h>

int main() {
    pid_t pid_active, pid_passive;

    pid_active = fork();
    if (pid_active == 0) {
        execl("./active.out", "active.out", NULL);
        perror("exec active failed");
        exit(1);
    }

    pid_passive = fork();
    if (pid_passive == 0) {
        execl("./passive.out", "passive.out", NULL);
        perror("exec passive failed");
        exit(1);
    }

    sleep(2); // подождём, пока оба запустятся

    time_t now = time(NULL);
    printf("SENDER: отправляю SIGUSR1 в %s", ctime(&now));

    kill(pid_active, SIGUSR1);
    kill(pid_passive, SIGUSR1);

    // ждём завершения обоих
    waitpid(pid_active, NULL, 0);
    waitpid(pid_passive, NULL, 0);

    printf("SENDER: оба процесса завершились\n");
    return 0;
}

