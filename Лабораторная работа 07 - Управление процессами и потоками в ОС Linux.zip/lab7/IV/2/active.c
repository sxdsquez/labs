#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>

void handle_signal(int sig) {
    time_t now = time(NULL);
    printf("ACTIVE: получил сигнал %d в %s", sig, ctime(&now));
}

int main() {
    signal(SIGUSR1, handle_signal);

    for (int i = 0; i < 100; i++) {
        usleep(100000); // 0.1 сек
    }

    return 0;
}

