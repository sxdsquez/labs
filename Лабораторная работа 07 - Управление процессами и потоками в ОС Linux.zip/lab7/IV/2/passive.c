#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>

void handle_signal(int sig) {
    time_t now = time(NULL);
    printf("PASSIVE: получил сигнал %d в %s", sig, ctime(&now));
}

int main() {
    signal(SIGUSR1, handle_signal);
    sleep(10);
    return 0;
}

