#include <stdio.h>
#include <unistd.h>
#include <signal.h>

void handle_sigusr1(int sig) {
    printf("CHILD 3: поймал сигнал %d — SIGUSR1!\n", sig);
}

int main() {
    signal(SIGUSR1, handle_sigusr1);
    printf("CHILD 3: жду сигнал SIGUSR1\n");
    pause(); // ждёт сигнал
    printf("CHILD 3: продолжаю работу после сигнала\n");
    return 0;
}

