#include <stdio.h>
#include <unistd.h>

int main() {
    printf("CHILD 1: жду сигнал (по умолчанию завершаюсь)\n");
    pause(); // ждёт сигнал
    printf("CHILD 1: не должен был дойти до сюда\n");
    return 0;
}

