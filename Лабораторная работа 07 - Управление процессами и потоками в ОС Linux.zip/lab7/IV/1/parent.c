#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>

int main() {
    pid_t pid1, pid2, pid3;

    pid1 = fork();
    if (pid1 == 0) execl("./child1.out", "child1.out", NULL);

    pid2 = fork();
    if (pid2 == 0) execl("./child2.out", "child2.out", NULL);

    pid3 = fork();
    if (pid3 == 0) execl("./child3.out", "child3.out", NULL);

    sleep(2); // ждём, чтобы дети точно запустились

    printf("PARENT: посылаю SIGUSR1 всем детям\n");
    kill(pid1, SIGUSR1);
    kill(pid2, SIGUSR1);
    kill(pid3, SIGUSR1);

    // ждём завершения
    wait(NULL);
    wait(NULL);
    wait(NULL);

    printf("PARENT: завершил работу\n");
    return 0;
}

