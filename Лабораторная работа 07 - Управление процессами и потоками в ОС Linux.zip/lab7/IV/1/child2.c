#include <stdio.h>
#include <unistd.h>
#include <signal.h>

int main() {
    signal(SIGUSR1, SIG_IGN); // игнорировать сигнал
    printf("CHILD 2: сигнал будет проигнорирован\n");
    sleep(5); // имитируем работу
    printf("CHILD 2: завершил работу\n");
    return 0;
}

