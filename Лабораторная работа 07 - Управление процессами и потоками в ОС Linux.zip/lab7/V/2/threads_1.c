#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void* thread1_func(void* arg) {
    int count = 0;
    while (count < 10) { // три интервала по 5 секунд (всего 15 сек)
        printf("Поток 1: прошло %d интервалов по 5 сек\n", count);
        sleep(5);
        count++;
    }
    printf("Поток 1: завершен\n");
    return NULL;
}

void* thread2_func(void* arg) {
    int count = 0;
    while (count < 150) { // пятнадцать интервалов по 1 сек (тоже 15 сек)
        printf("Поток 2: прошло %d интервалов по 1 сек\n", count);
        sleep(1);
        count++;
    }
    printf("Поток 2: завершен\n");
    return NULL;
}

int main() {
    pthread_t t1, t2;

    printf("Главный поток: запускаю потоки\n");

    pthread_create(&t1, NULL, thread1_func, NULL);
    pthread_create(&t2, NULL, thread2_func, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    printf("Главный поток: оба потока завершены\n");
    return 0;
}

