#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <signal.h>

pthread_t t2; // глобальный идентификатор второго потока

// Обработчик сигнала в потоке 2
void handle_signal(int sig) {
    if (sig == SIGUSR1) {
        printf("Поток 2: получил сигнал SIGUSR1 — завершаюсь\n");
        pthread_exit(NULL); // завершение потока 2
    }
}

void* thread1_func(void* arg) {
    printf("Поток 1: стартовал, сплю 5 сек...\n");
    sleep(5);

    printf("Поток 1: отправляю SIGUSR1 потоку 2\n");
    pthread_kill(t2, SIGUSR1);

    printf("Поток 1: продолжаю работу (ещё 5 сек)\n");
    sleep(5);
    printf("Поток 1: завершен\n");
    return NULL;
}

void* thread2_func(void* arg) {
    signal(SIGUSR1, handle_signal);
    printf("Поток 2: стартовал, работаю до сигнала...\n");

    while (1) {
        printf("Поток 2: жив\n");
        sleep(1);
    }
    return NULL;
}

int main() {
    pthread_t t1;

    printf("Главный поток: запускаю потоки\n");

    pthread_create(&t1, NULL, thread1_func, NULL);
    pthread_create(&t2, NULL, thread2_func, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    printf("Главный поток: оба потока завершены\n");
    return 0;
}

