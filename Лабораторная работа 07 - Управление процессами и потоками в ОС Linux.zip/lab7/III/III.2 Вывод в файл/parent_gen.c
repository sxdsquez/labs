#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

void separator(const char* label) {
    printf("\n================== %s ==================\n", label);
}

int main() {
    // Перенаправляем stdout в файл
    FILE* file = fopen("result.txt", "w");
    if (!file) {
        perror("Ошибка открытия файла");
        return 1;
    }

    dup2(fileno(file), STDOUT_FILENO); // вывод в файл
    setvbuf(stdout, NULL, _IOLBF, 0);  // построчная буферизация

    // ===== A. Родитель ждёт потомка =====
    separator("СИТУАЦИЯ A — родитель ждёт потомка");
    if (fork() == 0) {
        execl("./child_A.out", "child_A.out", NULL);
        perror("execl A failed");
        exit(1);
    }
    wait(NULL); // ждём завершения потомка

    // ===== B. Родитель завершает, потомок становится сиротой =====
    separator("СИТУАЦИЯ B — родитель завершает сразу (сирота)");

    if (fork() == 0) {
        // первый дочерний процесс (временно родитель для внука)
        if (fork() == 0) {
            // внук, настоящий потомок
            execl("./child_B.out", "child_B.out", NULL);
            perror("execl B failed");
            exit(1);
        }
        sleep(1);
        // первый дочерний завершается → внук станет сиротой
        exit(0);
    }

    sleep(6); // даём потомку B время завершиться и показать новый ppid

    // ===== C. Родитель остаётся, потомок завершился (зомби) =====
    separator("СИТУАЦИЯ C — зомби");

    if (fork() == 0) {
        execl("./child_C.out", "child_C.out", NULL);
        perror("execl C failed");
        exit(1);
    }

    // Родитель НЕ вызывает wait — ждём и смотрим таблицу процессов
    sleep(5);
    system("ps -t pts/0");

    fclose(file);
    return 0;
}

