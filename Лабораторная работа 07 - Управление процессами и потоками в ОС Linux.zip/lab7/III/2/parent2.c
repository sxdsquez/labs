#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    int pid = getpid();
    int ppid = getppid();

    printf("PARENT PARAM: pid = %d  ppid = %d\n", pid, ppid);

    if (fork() == 0) {
        execl("./child.out", "child.out", NULL);
        perror("execl failed");
        exit(1);
    }

	sleep(2);

    return 0;
}

