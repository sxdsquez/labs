#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    int pid = getpid();
    int ppid = getppid();

    printf("PARENT PARAM: pid = %d  ppid = %d\n", pid, ppid);

    if (fork() == 0) {
        execl("./child.out", "child.out", NULL);
        perror("execl failed");
        exit(1);
    }

    sleep(20); // Ждём, чтобы потомок успел завершиться, а родитель ещё жил

    system("ps -t pts/0");

    return 0;
}

