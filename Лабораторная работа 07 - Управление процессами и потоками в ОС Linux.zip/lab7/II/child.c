#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main() {
    int pid = getpid();
    int ppid = getppid();

    printf("CHILD START: pid = %d  ppid = %d\n", pid, ppid);

    sleep(10);

    ppid = getppid();
    printf("CHILD AFTER: pid = %d  NEW ppid = %d\n", pid, ppid);

    return 0;
}

