#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main() {
    int pid, ppid, status;
    pid = getpid();
    ppid = getppid();

    printf("\nPARENT PARAM: pid = %d  ppid = %d\n", pid, ppid);

    if (fork() == 0) {
        // Это дочерний процесс: запускаем исполняемый файл "child"
        execl("./child.out", "child.out", NULL);
        perror("execl failed");
        exit(1); // Если execl не сработал
    }

    // Родительский процесс: записываем таблицу процессов в файл
    system("ps -axf > ps_before_wait.txt");

    // Ждём завершения дочернего процесса
    wait(&status);

    return 0;
}

