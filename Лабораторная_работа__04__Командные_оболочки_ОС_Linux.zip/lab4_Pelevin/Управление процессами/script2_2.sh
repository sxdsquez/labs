#!/bin/bash

#вывод списка процессов, у которых установлены стандартные
#обработчики (SIG_DFL или SIG_IGN) для типа 
#сигнала, заданного в командной строке;

# Проверка аргумента
if [ -z "$1" ]; then
    echo "Использование: $0 <SIGNAME или номер сигнала>"
    exit 1
fi

SIGNAL="$1"

echo "Процессы с установленными обработчиками SIG_DFL или SIG_IGN для сигнала $SIGNAL:"
echo "-----------------------------------------------------------------------------------"

# Проходим по всем процессам
for pid in $(ls /proc | grep -E '^[0-9]+$'); do
    # Проверка, существует ли /proc/<pid>/status
    if [ -r "/proc/$pid/status" ]; then
        # Извлекаем имя команды
        cmd=$(grep "^Name:" /proc/$pid/status | awk '{print $2}')

        # Извлекаем маски сигналов
        sigign=$(grep "^SigIgn:" /proc/$pid/status | awk '{print $2}')
        sigcgt=$(grep "^SigCgt:" /proc/$pid/status | awk '{print $2}')

        # Получаем номер сигнала, если задан по имени
        if [[ "$SIGNAL" =~ ^[0-9]+$ ]]; then
            sig_num="$SIGNAL"
        else
            sig_num=$(kill -l "$SIGNAL" 2>/dev/null | awk '{print $1}')
        fi

        # Проверка: если не удалось получить номер сигнала
        if ! [[ "$sig_num" =~ ^[0-9]+$ ]]; then
            echo "Неверный сигнал: $SIGNAL"
            exit 1
        fi

        # Рассчитываем битовую маску
        bitmask=$((1 << ($sig_num - 1)))

        # Преобразуем из hex в decimal
        sigign_dec=$((0x$sigign))
        sigcgt_dec=$((0x$sigcgt))

        # Проверка: игнорируется (SIG_IGN) или используется по умолчанию (SIG_DFL)
        if (( sigign_dec & bitmask )); then
            echo "$pid [$cmd]: SIG_IGN"
        elif ! (( sigcgt_dec & bitmask )); then
            echo "$pid [$cmd]: SIG_DFL"
        fi
    fi
done

