#!/bin/bash

#завершение пользовательского сеанса работы в ОС 
#в конце рабочего времени с учётом сокращения его
#длительности в предпраздничные дни;

# Настройки времени окончания работы
END_HOUR_NORMAL=18
END_HOUR_SHORTENED=16

# Файл с датами праздников
HOLIDAYS_FILE="/etc/short_days.txt"

# Текущая дата и время
TODAY_DATE=$(date +%F)
TODAY_EPOCH=$(date -d "$TODAY_DATE" +%s)
CURRENT_HOUR=$(date +%H)

# По умолчанию считаем день обычным
IS_SHORTENED=false

# Проверяем, есть ли праздники в файле
if [ -f "$HOLIDAYS_FILE" ]; then
    while read -r holiday_date; do
        # Получаем дату праздника в формате секунд
        HOLIDAY_EPOCH=$(date -d "$holiday_date" +%s)

        # Разница в днях
        DAYS_DIFF=$(( (HOLIDAY_EPOCH - TODAY_EPOCH) / 86400 ))

        # Только за 1-2 дня до праздника
        if [ "$DAYS_DIFF" -eq 1 ] || [ "$DAYS_DIFF" -eq 2 ]; then
            IS_SHORTENED=true
            break
        fi
    done < "$HOLIDAYS_FILE"
fi

# Устанавливаем лимит времени окончания рабочего дня
if [ "$IS_SHORTENED" = true ]; then
    LIMIT=$END_HOUR_SHORTENED
else
    LIMIT=$END_HOUR_NORMAL
fi

# Завершаем сессию, если текущее время превышает лимит
if [ "$CURRENT_HOUR" -ge "$LIMIT" ]; then
    echo "Сейчас $CURRENT_HOUR:00. Рабочий день завершён (лимит $LIMIT:00). Завершаем сеанс..."
    pkill -KILL -u "$USER"
else
    echo "Сейчас $CURRENT_HOUR:00. Рабочий день ещё продолжается (лимит $LIMIT:00)."
fi

