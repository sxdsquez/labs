#!/bin/bash

#Вывод содержимого файла /etc/passwd в виде таблицы с заданным в командной строке значением интервала между столбцами

# Проверка на количество аргументов
if [ $# -ne 1 ]; then
    echo "Использование: $0 <интервал>"
    exit 1
fi

spacing=$1

# Проверка, что интервал — это число
if ! [[ $spacing =~ ^[0-9]+$ ]]; then
    echo "Ошибка: интервал должен быть числом."
    exit 1
fi

# Заголовки столбцов
headers=("Username" "Password" "UID" "GID" "Info" "Home Dir" "Shell")
# создаем массив заголовков столбцов
header_line=$(printf "%-15s%${spacing}s%-8s%${spacing}s%-10s%${spacing}s%-10s%${spacing}s%-50s%${spacing}s%-20s%${spacing}s%-20s\\n" \
                   "${headers[0]}" "" "${headers[1]}" "" "${headers[2]}" "" "${headers[3]}" "" "${headers[4]}" "" "${headers[5]}" "" "${headers[6]}" "" "${headers[7]}")

echo "$header_line"
divider_length=$(($spacing + 143))
echo "$(printf '=%.0s' $(seq 1 $divider_length))"

while IFS=: read -r user pass uid gid info home shell; do
    printf "%-15s%${spacing}s%-8s%${spacing}s%-10s%${spacing}s%-10s%${spacing}s%-50s%${spacing}s%-20s%${spacing}s%-20s\\n" \
           "$user" "" "$pass" "" "$uid" "" "$gid" "" "$info" "" "$home" "" "$shell"
done < /etc/passwd

