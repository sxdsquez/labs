#!/bin/bash

#Удаление из заданного в командной строке файла сценария всех комментариев (за исключением строки с именем интерпретатора сценария)

your_script=$1

if [ -z "$your_script" ]; then
  echo "Введите имя файла"
  exit 1
fi

# Проверка на существование файла
if [[ -f "$your_script" ]]; then
    # Выполняем удаление комментариев
    sed '1!{/^#/d}' $your_script > temp_script.sh && mv temp_script.sh $your_script
else
    echo "Ошибка: файл $your_script не существует."
    exit 1
fi

echo "Комментарии из сценария $your_script удалены"

