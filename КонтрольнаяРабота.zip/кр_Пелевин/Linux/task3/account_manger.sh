#!/bin/bash

JOURNAL="journal.log"
CONFIG="accounts.conf"

log() {
    echo "[$(date +'%F %T')] $1" >> "$JOURNAL"
}

show_menu() {
    echo -e "\n--- Меню управления ---"
    echo "1. Показать конфигурацию"
    echo "2. Создать пользователя"
    echo "3. Изменить пользователя"
    echo "4. Удалить пользователя"
    echo "5. Выход"
    echo -n "Выберите действие: "
}

show_config() {
    echo -e "\n--- Текущая конфигурация ---"
    cat "$CONFIG"
    log "Просмотр конфигурации"
}

create_user() {
    read -p "Введите имя пользователя: " uname
    grep -q "^$uname$" users.conf || { echo "Имя недопустимо!"; return; }

    read -p "UID: " uid
    read -p "GID: " gid
    read -p "Пароль: " pass
    read -p "Домашний каталог: " home
    read -p "Оболочка: " shell
    read -p "Срок действия (например: never): " exp

    echo "user;$uname;UID=$uid;GID=$gid;PASS=$pass;HOME=$home;SHELL=$shell;EXP=$exp" >> "$CONFIG"
    log "Создан пользователь $uname"
}

edit_user() {
    read -p "Имя пользователя для изменения: " uname
    grep -q "^user;$uname;" "$CONFIG" || { echo "Пользователь не найден."; return; }

    read -p "Новое имя (или Enter для пропуска): " newname
    read -p "Новый UID (или Enter): " newuid

    TMP=$(mktemp)
    while IFS= read -r line; do
        if [[ $line == user\;$uname\;* ]]; then
            [[ -n $newname ]] && line=$(echo "$line" | sed "s/^user;$uname;/user;$newname;/")
            [[ -n $newuid ]] && line=$(echo "$line" | sed -E "s/UID=[^;]+/UID=$newuid/")
        fi
        echo "$line" >> "$TMP"
    done < "$CONFIG"

    mv "$TMP" "$CONFIG"
    log "Изменён пользователь $uname"
}

delete_user() {
    read -p "Имя пользователя для удаления: " uname
    grep -q "^user;$uname;" "$CONFIG" || { echo "Пользователь не найден."; return; }

    grep -v "^user;$uname;" "$CONFIG" > tmp && mv tmp "$CONFIG"
    log "Удалён пользователь $uname"
}

# Основной цикл
while true; do
    show_menu
    read cmd
    case $cmd in
        1) show_config ;;
        2) create_user ;;
        3) edit_user ;;
        4) delete_user ;;
        5) log "Выход из программы"; exit 0 ;;
        *) echo "Неверный выбор!" ;;
    esac
done

