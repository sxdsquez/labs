#!/bin/bash

VARIANT="09"
read -p "Введите имя файла-копии (по умолчанию ManReport$VARIANT): " FILE
FILE=${FILE:-ManReport$VARIANT}

read -p "Введите имя системной команды или утилиты: " COMMAND

if ! man "$COMMAND" > /dev/null 2>&1; then
    echo "Ошибка: man-страница для '$COMMAND' не найдена."
    exit 1
fi

> "$FILE"

while IFS= read -r CHAPTER; do
    man "$COMMAND" | awk -v chap="$CHAPTER" \
    '/^[A-Z]/ {flag=0} $0 ~ "^" chap "$" {flag=1; print} flag' | sed '$d' >> "$FILE"
done < chapters.conf

echo "Содержимое файла '$FILE':"
cat "$FILE"
