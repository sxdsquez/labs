#!/bin/bash

read -p "Введите имя набора данных (например: data1): " DATA
JOURNAL="journal.log"

# Очистка предыдущего журнала
> "$JOURNAL"

# Проверка конфигураций
if [[ ! -f mixture.conf || ! -f timetable.conf ]]; then
    echo "Файлы mixture.conf или timetable.conf не найдены!"
    exit 1
fi

# Временная папка для скриптов
mkdir -p scripts

# Создание исполняемых мини-скриптов для каждого действия
while IFS=';' read -r ACTION DESC; do
    SCRIPT="scripts/$ACTION.sh"
    echo "#!/bin/bash" > "$SCRIPT"
    echo "echo \"[$(date)] Выполнение: $DESC, набор данных: $DATA\" >> $JOURNAL" >> "$SCRIPT"

    case "$ACTION" in
        pwd)
            echo "pwd >> $JOURNAL" >> "$SCRIPT"
            ;;
        player)
            echo "echo 'Музыка играет 🎵' >> $JOURNAL" >> "$SCRIPT"
            ;;
        archive)
            echo "tar -czf /tmp/root_home_\$(date +%F).tar.gz /root 2>> $JOURNAL && echo 'Архив создан' >> $JOURNAL" >> "$SCRIPT"
            ;;
        msgbox)
            echo "echo 'Happy New Year !' >> $JOURNAL" >> "$SCRIPT"
            ;;
    esac

    chmod +x "$SCRIPT"
done < mixture.conf

# Генерация crontab
TMPCRON="mycron.tmp"
> "$TMPCRON"

while read -r LINE; do
    SCHEDULE=$(echo "$LINE" | awk '{$NF=""; print $0}')
    ACTION=$(echo "$LINE" | awk '{print $NF}')
    echo "$SCHEDULE $(pwd)/scripts/$ACTION.sh" >> "$TMPCRON"
done < timetable.conf

# Установка crontab
crontab "$TMPCRON"
rm "$TMPCRON"

echo "Готово! Задания установлены в crontab."

