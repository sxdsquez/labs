﻿param (
    [int]$Interval = 5  # интервал в секундах между запусками
)

Write-Host "Старт потока notepad.exe с интервалом $Interval секунд. Для остановки нажмите Ctrl+C."

while ($true) {
    Start-Process "notepad.exe"
    Write-Host "Процесс notepad.exe запущен. Текущие процессы:"
    Get-Process notepad | Select-Object Id, CPU, StartTime | Format-Table
    Start-Sleep -Seconds $Interval
}
