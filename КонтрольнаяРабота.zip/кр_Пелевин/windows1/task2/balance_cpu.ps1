﻿param (
    [int]$Threshold = 10  # лимит CPU в процентах
)

Write-Host "Мониторинг CPU для notepad.exe. Порог: $Threshold%. Для остановки нажмите Ctrl+C.`n"

while ($true) {
    $notepads = Get-Process notepad -ErrorAction SilentlyContinue
    if ($notepads) {
        # Суммарная загрузка CPU
        $totalCPU = ($notepads | Measure-Object -Property CPU -Sum).Sum
        Write-Host "Суммарная загрузка CPU (в секундах): $([math]::Round($totalCPU, 2))"
        Write-Host "Количество процессов: $($notepads.Count)"

        # Допустим 1 секунда CPU примерно равна 1% нагрузки в момент времени (грубо)
        if ($totalCPU -gt $Threshold) {
            Write-Host "`nПревышен порог. Завершаем процессы в порядке увеличения PID..."

            # Удаление "лишних" процессов по порядку
            $ordered = $notepads | Sort-Object Id
            foreach ($proc in $ordered) {
                try {
                    Stop-Process -Id $proc.Id -Force
                    Write-Host "Процесс с ID $($proc.Id) завершён."
                    # Перепроверка после удаления
                    $notepads = Get-Process notepad -ErrorAction SilentlyContinue
                    $totalCPU = ($notepads | Measure-Object -Property CPU -Sum).Sum
                    if ($totalCPU -le $Threshold) {
                        break
                    }
                } catch {
                    Write-Host "Не удалось завершить процесс с ID $($proc.Id)"
                }
            }
        }
    } else {
        Write-Host "Процессы notepad.exe не найдены."
    }
    Start-Sleep -Seconds 5
    Write-Host ""
}
