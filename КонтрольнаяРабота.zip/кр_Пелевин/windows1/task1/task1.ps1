﻿# Ввод расширения файла
$fileType = Read-Host "Введите расширение файла (например: odt)"

# Получение системной информации
$computerName = $env:COMPUTERNAME
$workgroup = (Get-WmiObject Win32_ComputerSystem).Domain
$currentUser = $env:USERNAME

# Попытка получить информацию из реестра
try {
    $extensionKey = "Registry::HKEY_CLASSES_ROOT\.$fileType"
    $contentType = (Get-ItemProperty -Path $extensionKey).ContentType
    $fileClass = (Get-ItemProperty -Path $extensionKey)."(default)"
    $assocAppKey = "Registry::HKEY_CLASSES_ROOT\$fileClass\shell\open\command"
    $associatedApp = (Get-ItemProperty -Path $assocAppKey)."(default)"
} catch {
    $contentType = "Не найдено"
    $associatedApp = "Не найдено"
}

# Поиск файлов на всех логических дисках
$foundFiles = Get-PSDrive -PSProvider FileSystem | ForEach-Object {
    Get-ChildItem $_.Root -Recurse -Filter "*.$fileType" -ErrorAction SilentlyContinue
} | Sort-Object { $_.Name.Length } -Descending

if ($foundFiles.Count -gt 0) {
    $selectedFile = $foundFiles[0]
    $result = "Success"
    $filePath = $selectedFile.FullName
    $fileNameLength = $selectedFile.Name.Length
} else {
    $result = "Failure"
}

# Составление текста отчета
$output = @"
ОТЧЁТ О ВЫПОЛНЕНИИ СКРИПТА

СИСТЕМНАЯ ИНФОРМАЦИЯ:
- Имя компьютера: $computerName
- Рабочая группа: $workgroup
- Имя пользователя: $currentUser

ИНФОРМАЦИЯ О ТИПЕ ФАЙЛА: .$fileType
- Тип содержимого: $contentType
- Приложение по умолчанию: $associatedApp

РЕЗУЛЬТАТ ПОИСКА:
- Статус: $result
"@

if ($result -eq "Success") {
    $output += @"
- Путь к файлу: $filePath
- Длина имени файла: $fileNameLength
"@
}

# Сохранение файла в UTF-8 с BOM
$reportPath = "$env:TEMP\report_$fileType.txt"
$utf8bom = New-Object System.Text.UTF8Encoding($true)
[System.IO.File]::WriteAllText($reportPath, $output, $utf8bom)

# Открытие отчета в блокноте
Start-Process notepad.exe $reportPath
