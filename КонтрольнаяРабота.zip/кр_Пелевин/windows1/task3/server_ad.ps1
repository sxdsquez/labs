﻿# Создание групп
$groups = @("Buh", "Kadr", "Yur")
foreach ($group in $groups) {
    if (-not (Get-ADGroup -Filter "Name -eq '$group'")) {
        New-ADGroup -Name $group -GroupScope Global -GroupCategory Security
        Write-Host "Создана группа: $group"
    }
}

# Создание пользователей
$users = @("Anna", "Irina", "Oleg", "Ivan")
foreach ($user in $users) {
    if (-not (Get-ADUser -Filter "SamAccountName -eq '$user'")) {
        $password = ConvertTo-SecureString "P@ssw0rd!" -AsPlainText -Force
        New-ADUser -Name $user -SamAccountName $user -AccountPassword $password -Enabled $true
        Write-Host "Создан пользователь: $user"
    }
}

# Назначение пользователей в группы (по шаблону)
Add-ADGroupMember -Identity "Buh" -Members "Anna"
Add-ADGroupMember -Identity "Kadr" -Members "Irina","Oleg"
Add-ADGroupMember -Identity "Yur" -Members "Ivan"

# Создание папки и задание прав
$folderPath = "C:\Baza\F9"
if (-not (Test-Path $folderPath)) {
    New-Item -Path $folderPath -ItemType Directory | Out-Null
    Write-Host "Создана папка: $folderPath"
}

# Очистка и установка прав
$acl = Get-Acl $folderPath
$acl.SetAccessRuleProtection($true, $false)  # отключаем наследование

# Права по группам
$rules = @(
    @{Group = "Buh"; Right = "Read"},
    @{Group = "Kadr"; Right = "Modify"},
    @{Group = "Yur";  Right = "FullControl"}
)

foreach ($r in $rules) {
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule("$env:USERDOMAIN\$($r.Group)", $r.Right, "ContainerInherit,ObjectInherit", "None", "Allow")
    $acl.AddAccessRule($rule)
}

Set-Acl -Path $folderPath -AclObject $acl

# Вывод отчета
Write-Host "`nИтог:"
Write-Host "Создано пользователей: $($users.Count)"
Write-Host "Создано групп: $($groups.Count)"
Write-Host "Назначены права доступа к папке: $folderPath"
