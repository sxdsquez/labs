﻿param (
    [string]$UserName
)

if (-not $UserName) {
    $UserName = Read-Host "Введите имя пользователя (например, Irina)"
}

# Получаем группы пользователя
$user = Get-ADUser -Identity $UserName -Properties MemberOf
$groups = ($user.MemberOf | ForEach-Object {
    ($_ -split ',')[0] -replace "^CN="
})

# Путь к расшаренной папке
$resource = "\\DC\Baza\F9"

Write-Host "`nПроверка доступа к ресурсу: $resource"
Write-Host "Пользователь: $UserName"
Write-Host "Группы: $($groups -join ', ')`n"

# Простой вывод на основе логики твоего варианта:
$accessMatrix = @{
    "Buh"  = "Read"
    "Kadr" = "Change (Modify)"
    "Yur"  = "FullControl"
}

$hasAccess = $false
foreach ($group in $groups) {
    if ($accessMatrix.ContainsKey($group)) {
        Write-Host "Группа $group даёт право: $($accessMatrix[$group])"
        $hasAccess = $true
    }
}

if (-not $hasAccess) {
    Write-Host "У пользователя нет прав на доступ к ресурсу."
}
